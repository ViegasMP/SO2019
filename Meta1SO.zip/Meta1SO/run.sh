clear
gcc -Wall -pthread main.c -o main
./main